<?php
/**
 * The main template file.
 *
 * @package DW Page
 * @since DW Page 1.0
 */

get_header(); ?>

<?php dw_page_display(); ?>

<?php get_footer(); ?>